package tmltranslator.tomappingsystemc2;

public class idtypewrap{
	String id;
	int type;
	int nbOfIDs;
	idtypewrap(int _type, String _id, int _nbOfIDs){
		id=_id;
		type=_type;
		nbOfIDs=_nbOfIDs;
	}
}