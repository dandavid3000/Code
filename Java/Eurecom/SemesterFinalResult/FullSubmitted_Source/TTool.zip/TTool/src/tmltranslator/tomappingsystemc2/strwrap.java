package tmltranslator.tomappingsystemc2;

public class strwrap{
	String str;
	strwrap(String iStr){
		str=iStr;
	}
	strwrap(){
		str="";
	}
}