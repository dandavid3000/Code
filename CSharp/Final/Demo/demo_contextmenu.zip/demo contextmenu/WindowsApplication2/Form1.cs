using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsApplication2
{
    public partial class Form1 : Form
    {
        ContextMenuStrip ctmDemo;
        public Form1()
        {
            InitializeComponent();
            ctmDemo = new ContextMenuStrip();
            ctmDemo.Items.Add("Copy");
            ctmDemo.Items.Add("Cut");
            ctmDemo.Items.Add("Paste");
            ctmDemo.Click += new EventHandler(contextMenuStrip_Click);
            this.ContextMenuStrip = ctmDemo;
        }

        private void contextMenuStrip_Click(object sender, EventArgs e)
        {
            MessageBox.Show("da thuc hien", "thong bao", MessageBoxButtons.OK);
        }

    }
    
}