using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace Week6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            tvwDir.ImageList = new ImageList();
            tvwDir.ImageList.Images.Add(new Icon("icons/mycomputer.ico"));
            tvwDir.ImageList.Images.Add(new Icon("icons/drive.ico"));
            tvwDir.ImageList.Images.Add(new Icon("icons/folder_close.ico"));
            tvwDir.ImageList.Images.Add(new Icon("icons/folder_open.ico"));
            tvwDir.ImageList.Images.Add(new Icon("icons/document.ico"));

            lvwDir.SmallImageList = new ImageList();
            lvwDir.LargeImageList = new ImageList();
            lvwDir.View = View.Tile;
            lvwDir.SmallImageList.Images.Add(new Icon("icons/drive.ico"));
            lvwDir.SmallImageList.Images.Add(new Icon("icons/folder_close.ico"));
            lvwDir.SmallImageList.Images.Add(new Icon("icons/folder_open.ico"));
            lvwDir.SmallImageList.Images.Add(new Icon("icons/document.ico"));
            lvwDir.LargeImageList.Images.Add(new Icon("icons/drive.ico"));
            lvwDir.LargeImageList.Images.Add(new Icon("icons/folder_close.ico"));
            lvwDir.LargeImageList.Images.Add(new Icon("icons/folder_open.ico"));
            lvwDir.LargeImageList.Images.Add(new Icon("icons/document.ico"));

            TreeNode mycomputer = new TreeNode();
            mycomputer.Tag = "My Computer";
            mycomputer.ImageIndex = 0;
            mycomputer.SelectedImageIndex = 0;
            mycomputer.Text = "My Computer";
            tvwDir.Nodes.Add(mycomputer);
            tvwDir.SelectedNode = mycomputer;


        }

        private void tvwDir_AfterSelect(object sender, TreeViewEventArgs e)
        {
            
            TreeNode selectedNode = tvwDir.SelectedNode;
            selectedNode.Nodes.Clear();
            lvwDir.Items.Clear();

            if(selectedNode.Tag.ToString()=="My Computer")
            {
                foreach (DriveInfo drive in DriveInfo.GetDrives())
                {
                    //them cac node con ben TreeView
                    TreeNode d = new TreeNode(drive.Name);

                    d.Tag = drive.RootDirectory;
                    d.ImageIndex = 1;
                    d.SelectedImageIndex = 1;
                    if (drive.IsReady) d.Text += "[" + drive.VolumeLabel + "]";
                    selectedNode.Nodes.Add(d);

                    //them cac item con ben listview
                    ListViewItem lvi = new ListViewItem();
                    lvi.Text = drive.Name;
                    lvi.Tag = drive.RootDirectory;
                    lvi.ImageIndex = 0;
                    lvwDir.Items.Add(lvi);

                }
            }
            else
            {
                
                if(selectedNode.Tag.GetType()==typeof(DirectoryInfo))
                {
                    //xu ly cac thu muc
                    DirectoryInfo curDir = new DirectoryInfo(((DirectoryInfo)(selectedNode.Tag)).FullName);
                    foreach(DirectoryInfo dir in curDir.GetDirectories())
                    {
                        //them cac node ben TreeView
                        TreeNode newNode = new TreeNode(dir.Name);
                        newNode.ImageIndex = 2;
                        newNode.SelectedImageIndex = 3;
                        newNode.Tag = dir;
                        selectedNode.Nodes.Add(newNode);
                        //them cac item thu muc con ben ListView
                        ListViewItem lvi = new ListViewItem();
                        lvi.Tag = dir.FullName;
                        lvi.Text = dir.Name;
                        lvi.ImageIndex = 1;
                        lvwDir.Tag = selectedNode;
                        lvwDir.Items.Add(lvi);
                        
                    }

                    foreach(FileInfo file in curDir.GetFiles())
                    {
                        ListViewItem lvi = new ListViewItem();
                        lvi.Text = file.Name;
                        lvi.ImageIndex = 3;
                        lvi.Tag = file;
                        lvwDir.Items.Add(lvi);

                    }
                }
                
            }
            selectedNode.Expand();
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            switch(e.KeyCode)
            {
                case Keys.F7 :
                    {

                        ListViewItem lvi = new ListViewItem();
                        lvi.Text = "New Folder";
                        lvi.ImageIndex = 1;
                        lvwDir.Items.Add(lvi);
                        lvwDir.LabelEdit = true;
                        lvi.BeginEdit();
                        break;
                    }
            }
        }

        private void lvwDir_AfterLabelEdit(object sender, LabelEditEventArgs e)
        {
            
            //lay thong tin cua thu muc vua moi tao
            DirectoryInfo dir = Directory.CreateDirectory(((DirectoryInfo)(tvwDir.SelectedNode.Tag)).FullName+e.Label);

            //bat dau them node con moi cua node hien hanh
            TreeNode newNode = new TreeNode();
            newNode.Text = dir.Name;
            newNode.Tag = dir;
            newNode.ImageIndex = 2;
            tvwDir.SelectedNode.Nodes.Add(newNode);
            lvwDir.LabelEdit = false;

        }
    }
}